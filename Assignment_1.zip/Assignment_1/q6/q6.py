# write program to find 2nd order derivative and display image and 2nd order derivative
import cv2
import numpy as np
import matplotlib.pyplot as plt

# Load the image
image = cv2.imread('disney.jpg', cv2.IMREAD_GRAYSCALE)  # Load the image in grayscale


# Calculate the second-order derivative using the Laplacian operator
laplacian = cv2.Laplacian(image, cv2.CV_64F)

# Display the original image and second-order derivative
plt.figure(figsize=(10, 5))

# Original image
plt.subplot(1, 2, 1)
plt.title('Original Image')
plt.imshow(image, cmap='gray')
plt.axis('off')

# Second-order derivative (Laplacian)
plt.subplot(1, 2, 2)
plt.title('2nd Order Derivative (Laplacian)')
plt.imshow(laplacian, cmap='gray')
plt.axis('off')

plt.show()
