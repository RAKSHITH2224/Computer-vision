#write program to determine image gradient using sobel operators
import cv2
import numpy as np
import matplotlib.pyplot as plt

# Load the image (Replace 'your_image.jpg' with the correct image file path)
image = cv2.imread('flower.jpg', cv2.IMREAD_GRAYSCALE)  # Load the image in grayscale

# Calculate the gradient using Sobel operators
dx = cv2.Sobel(image, cv2.CV_64F, 1, 0, ksize=3)  # Gradient in the x-direction
dy = cv2.Sobel(image, cv2.CV_64F, 0, 1, ksize=3)  # Gradient in the y-direction

# Calculate gradient magnitude and direction
gradient_magnitude = np.sqrt(dx**2 + dy**2)
gradient_direction = np.arctan2(dy, dx)

# Display the original image, gradient magnitude, and gradient direction
plt.figure(figsize=(15, 5))

# Original image
plt.subplot(1, 3, 1)
plt.title('Original Image')
plt.imshow(image, cmap='gray')
plt.axis('off')

# Gradient magnitude
plt.subplot(1, 3, 2)
plt.title('Gradient Magnitude')
plt.imshow(gradient_magnitude, cmap='gray')
plt.axis('off')

# Gradient direction
plt.subplot(1, 3, 3)
plt.title('Gradient Direction')
plt.imshow(gradient_direction, cmap='gray')
plt.axis('off')

plt.show()
