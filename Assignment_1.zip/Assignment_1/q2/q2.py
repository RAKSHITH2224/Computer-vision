#write a program to display image histogram
import cv2
import matplotlib.pyplot as plt

# Load the image
image = cv2.imread('disney.jpg', cv2.IMREAD_GRAYSCALE)  # Load the image in grayscale

# Calculate the histogram
hist = cv2.calcHist([image], [0], None, [256], [0, 256])

# Plot the histogram
plt.figure()
plt.title('Image Histogram')
plt.xlabel('Pixel Value')
plt.ylabel('Frequency')
plt.plot(hist)
plt.xlim(0, 255)  # Set the x-axis limit to the range of pixel values (0-255)

# Show the plot
plt.show()
