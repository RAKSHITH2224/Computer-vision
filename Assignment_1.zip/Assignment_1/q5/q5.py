#write program to find 1st order derivative and display image and 1st order derivative
import cv2
import numpy as np
import matplotlib.pyplot as plt

# Load the image
image = cv2.imread('disney.jpg', cv2.IMREAD_GRAYSCALE)  # Load the image in grayscale

# Convert the image to a NumPy array
image_array = np.array(image, dtype=np.float32)

# Calculate the first-order derivative using NumPy
dx = np.gradient(image_array, axis=1)
dy = np.gradient(image_array, axis=0)

# Display the original image, derivative in x, and derivative in y
plt.figure(figsize=(15, 5))

# Original image
plt.subplot(1, 3, 1)
plt.title('Original Image')
plt.imshow(image, cmap='gray')
plt.axis('off')

# First-order derivative in x
plt.subplot(1, 3, 2)
plt.title('1st Order Derivative (X)')
plt.imshow(dx, cmap='gray')
plt.axis('off')

# First-order derivative in y
plt.subplot(1, 3, 3)
plt.title('1st Order Derivative (Y)')
plt.imshow(dy, cmap='gray')
plt.axis('off')

plt.show()
