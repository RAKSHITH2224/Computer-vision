#image enhancement using fourier transformations

import cv2
import numpy as np
import matplotlib.pyplot as plt

# Load the image (Replace 'your_image.jpg' with the correct image file path)
image = cv2.imread('flower.jpg', cv2.IMREAD_GRAYSCALE)  # Load the image in grayscale

# Perform a 2D Fourier Transform
f_transform = np.fft.fft2(image)
f_transform_shifted = np.fft.fftshift(f_transform)

# Create a high-pass filter (in the center of the frequency domain)
rows, cols = image.shape
crow, ccol = rows // 2, cols // 2
mask_size = 30
f_transform_shifted[crow - mask_size:crow + mask_size, ccol - mask_size:ccol + mask_size] = 0

# Perform an inverse Fourier Transform
f_transform_unshifted = np.fft.ifftshift(f_transform_shifted)
enhanced_image = np.fft.ifft2(f_transform_unshifted).real

# Display the original and enhanced images
plt.figure(figsize=(10, 5))

# Original image
plt.subplot(1, 2, 1)
plt.title('Original Image')
plt.imshow(image, cmap='gray')
plt.axis('off')

# Enhanced image
plt.subplot(1, 2, 2)
plt.title('Enhanced Image')
plt.imshow(enhanced_image, cmap='gray')
plt.axis('off')

plt.show()
