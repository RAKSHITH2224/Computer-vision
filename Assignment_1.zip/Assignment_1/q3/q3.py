#write a program for histogram equilization and display an image
import cv2
import numpy as np
import matplotlib.pyplot as plt

image = cv2.imread('disney.jpg', cv2.IMREAD_GRAYSCALE)

equalized_image = cv2.equalizeHist(image)



# Display the original and equalized images
plt.figure(figsize=(10, 5))

# Original image
plt.subplot(1, 2, 1)
plt.title('Original Image')
plt.imshow(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
plt.axis('off')

# Equalized image
plt.subplot(1, 2, 2)
plt.title('Equalized Image')
plt.imshow(cv2.cvtColor(equalized_image, cv2.COLOR_BGR2RGB))
plt.axis('off')

plt.show()
