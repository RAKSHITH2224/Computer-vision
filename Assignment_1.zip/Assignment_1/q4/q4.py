#write program to smooth image using gaussian filter and display image
import cv2
import matplotlib.pyplot as plt

# Load the image
image = cv2.imread('disney.jpg')


# Apply Gaussian blur to smooth the image
ksize = (5, 5)  # Adjust the kernel size as needed
sigmaX = 0  # You can adjust the sigma value for Gaussian blur
smoothed_image = cv2.GaussianBlur(image, ksize, sigmaX)

# Display the original and smoothed images
plt.figure(figsize=(10, 5))

# Original image
plt.subplot(1, 2, 1)
plt.title('Original Image')
plt.imshow(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
plt.axis('off')

# Smoothed image
plt.subplot(1, 2, 2)
plt.title('Smoothed Image')
plt.imshow(cv2.cvtColor(smoothed_image, cv2.COLOR_BGR2RGB))
plt.axis('off')

plt.show()
