#write a program to display image matrix
import cv2
import numpy as np
image = cv2.imread("F:\Projects\Assignment_1\q1\plus.png",cv2.IMREAD_GRAYSCALE)
image_matrix = np.array(image)
print(image_matrix)

#to save the matrix of a image into notepad
file_path = "F:\Projects\Assignment_1\q1\matrix_of_plus_image.txt"


# Open the file in write mode
with open(file_path, "w") as file:
    # Iterate over the matrix rows and write them to the file
    for row in image_matrix:
        # Convert each row to a string and write it to the file
        row_str = " ".join(map(str, row))  # Convert row to a space-separated string
        file.write(row_str + "\n")  # Write the row and add a newline

cv2.imshow("image as a matrix",image)
cv2.waitKey(0)
cv2.destroyAllWindows()